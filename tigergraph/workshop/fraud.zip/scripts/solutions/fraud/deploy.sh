#!/bin/bash

echo "----> Starting deployment of Anti-Fraud solution ..."

exit

echo "    ---- Waiting for MariaDB to revive ..."
while ! docker exec mariadb mysql --user=tigergraph --password=tigergraph --host="mariadb" --protocol="tcp" --execute 'SELECT 1;' >> /dev/null ; do
    sleep 10
done
echo "    ---- Initializing MariaDB Database (DDL) ..."
docker exec -i mariadb sh -c 'mysql -utigergraph -ptigergraph --default_character_set utf8mb4' < $SOL_DIR/tg_mariadb_ddl.sql
# granting privileges to user tigergraph
docker exec -i mariadb sh -c 'mysql -uroot -proot' < $SOL_DIR/tg_mariadb_grant_rights.sql

#sleep 5  # Temporary fix to allow TigerGraph to finish initialisation

echo "    ---- Waiting for TigerGraph to start roaring ..."
#cp $SOL_DIR/*.gsql $VOL_DIR/TigerGraph/scripts/ -> already under volume/TigerGraph/scripts !!
while ! docker exec tg_dev3 curl --fail http://localhost:9000/echo &> /dev/null ; do
    sleep 10
done
echo "    ---- Initializing TigerGraph database (DDL) ..."
docker exec -it --user tigergraph tg_dev3 sh -c "/opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/FraudGraph_ddl.gsql"
#echo "    ---- data loading in progress ---"
# not loading data, waiting for kafka
# ( (gunzip ${SOL_DIR}FraudGraph_data.csv.gz -f && mv ${SOL_DIR}FraudGraph_data.csv ${VOL_DIR}TigerGraph/scripts ) & )
# docker exec -it --user tigergraph tg_dev3 sh -c "/opt/tigergraph/app/cmd/gsql -g FraudGraph 'RUN LOADING JOB load_job_newdata_csv_1595052795555 USING MyDataSource=\"/home/tigergraph/scripts/FraudGraph_data.csv\"'"

echo "    ---- Configuring Kafka streaming platform ..."
# configuring source connector
echo "    ---- deploying MariaDB source connector ---"
curl -i -X POST localhost:8083/connectors/ -H "Accept:application/json" -H "Content-Type:application/json" -d @$SOL_DIR/debezium-mariadb-sink.json

echo "    ---- deploying TG sink connector "

# check if created
# curl -H "Accept:application/json" localhost:8083/connectors/

# check the status
# curl -H "Accept:application/json" localhost:8083/connectors/fraud-connector-source/status

# to delete this connector:
# curl -X DELETE http://localhost:8083/connectors/fraud-connector-source

# to check all topics
#  docker-compose exec kafka sh -c "./bin/kafka-topics.sh --zookeeper zookeeper:2181 --list"

# ./bin/kafka-avro-console-consumer \
#--bootstrap-server localhost:9092 \
#--property schema.registry.url=http://localhost:8081 \
#--topic fraud_server1.tg_demo.customer \
#--from-beginning | jq '.'

echo "    ---- Configuring Python/Conda/Jupyter"
# Installing Python libraries below should not be necessary, they should be covered by Dockerfile
# Remove the below line if that's done
#docker exec -it -u root conda bash -c "conda install -y numpy pandas pyyaml ipywidgets matplotlib seaborn"
#docker exec -it -u root conda bash -c "pip install sklearn catboost"
# Showing URL for Jupyter connection
# Completely disabling authentication might be a better idea (should not be of concern in workshop environment)
docker exec -it -u tigergraph conda bash -c "jupyter notebook list"
# Downloading required pyTigerGraph modules
# This should not be necessary once the required functionality is available in the build / via pip
# Remove this line if that's done
#wget -O ./scripts/solutions/fraud/pyTigerGraph.py https://raw.githubusercontent.com/szb-tg/pyTigerGraph/master/pyTigerGraph/pyTigerGraph.py
#wget -O ./scripts/solutions/fraud/pyTGCyto.py https://raw.githubusercontent.com/szb-tg/pyTigerGraph/master/pyTigerGraph/pyTGCyto.py
for F in `ls ./scripts/solutions/fraud/*.py` ; do
    docker cp $F conda:/home/tigergraph
done
# Deploying notebooks
for F in `ls ./scripts/solutions/fraud/*.ipynb` ; do
    docker cp $F conda:/home/tigergraph
done

echo "    ---- Starting LOADING DATA from MariaDB"
docker exec -it --user tigergraph tg_dev3 sh -c "/opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/FraudGraph_KafkaLoadJob.gsql"

echo "    ---- Initializing TigerGraph queries (GSQL) ..."
docker exec -it --user tigergraph tg_dev3 sh -c "/opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/FraudGraph_queries.gsql"

echo "    ---- Importing MariaDB transaction data ..."
gunzip < $SOL_DIR/tg_mariadb_smalldata.sql.gz | docker exec -i mariadb mysql -D tg_demo -utigergraph -ptigergraph --default_character_set utf8mb4 &


# cleanups !!!
# (delete scripts and data not used!)


echo "--> Done deployment Fraud!"
echo "####"
echo "To stop this workshop:        docker-compose stop"
echo "To terminate this workshop:   docker-compose down"
echo "####"
