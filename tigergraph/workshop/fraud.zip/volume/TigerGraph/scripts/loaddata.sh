#!/bin/bash
su - tigergraph /opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/tgtest.gsql
