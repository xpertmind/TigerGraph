#!/bin/bash

echo "Deploying Fraud solution ..."

echo "Installing MariaDB Database and loading some data ..."
sleep 10
gunzip < $SOL_DIR/tg_mariadb_smalldata.sql.gz | docker exec -i mariadb mysql -utigergraph -ptigergraph --default_character_set utf8mb4
# granting privileges to user tigergraph
docker exec -i mariadb sh -c 'mysql -uroot -proot' < $SOL_DIR/tg_mariadb_grant_rights.sql

sleep 5  # Temporary fix to allow TigerGraph to finish initialisation

echo "Installing TigerGraph schema ..."
cp $SOL_DIR/FraudGraph_ddl.gsql $VOL_DIR/TigerGraph/scripts/
docker exec -it --user tigergraph tg_dev3 sh -c "/opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/FraudGraph_ddl.gsql"
echo "Loading TigerGraph data ..."
gunzip ${SOL_DIR}FraudGraph_data.csv.gz > ${SOL_DIR}FraudGraph_data.csv
mv ${SOL_DIR}FraudGraph_data.csv ${VOL_DIR}TigerGraph/scripts
docker exec -it --user tigergraph tg_dev3 sh -c "/opt/tigergraph/app/cmd/gsql -g FraudGraph 'RUN LOADING JOB load_job_newdata_csv_1595052795555 USING MyDataSource=\"/home/tigergraph/scripts/FraudGraph_data.csv\"'"

echo "Configuring Kafka streaming platform"
# configuring source connector
echo " --- source connector"
curl -i -X POST localhost:8083/connectors/ -H "Accept:application/json" -H "Content-Type:application/json" \
--data-binary @- << EOF
{ "name": "fraud-connector-source",
  "config": {
    "connector.class": "io.debezium.connector.mysql.MySqlConnector",
    "tasks.max": "1",
    "database.hostname": "mariadb",
    "database.port": "3306",
    "database.user": "root",
    "database.password": "root",
    "database.server.id": "201311",
    "database.server.name": "fraud_server1",
    "database.whitelist": "tg_demo",
    "database.history.kafka.bootstrap.servers": "kafka:9092",
    "database.history.kafka.topic": "dbhistory.fraud",
    "include.schema.changes": "false"
  }
}
EOF

echo " --- sink connector"

# check if created
# curl -H "Accept:application/json" localhost:8083/connectors/

# check the status
# curl -H "Accept:application/json" localhost:8083/connectors/fraud-connector-source/status

# to delete this connector:
# curl -X DELETE http://localhost:8083/connectors/fraud-connector-source

# to check all topics
#  docker-compose exec kafka sh -c "./bin/kafka-topics.sh --zookeeper zookeeper:2181 --list"

# ./bin/kafka-avro-console-consumer \
#--bootstrap-server localhost:9092 \
#--property schema.registry.url=http://localhost:8081 \
#--topic fraud_server1.tg_demo.customer \
#--from-beginning | jq '.'

echo "Configuring Python/Conda/Jupyter ..."
# Installing Python libraries below should not be necessary, they should be covered by Dockerfile
# Remove the below line if that's done
docker exec -it -u root conda bash -c "conda install -y numpy pandas pyyaml ipywidgets matplotlib seaborn"
docker exec -it -u root conda bash -c "pip install sklearn catboost"
# Showing URL for Jupyter connection
# Completely disabling authentication might be a better idea (should not be of concern in workshop environment)
docker exec -it -u tigergraph conda bash -c "jupyter notebook list"
# Downloading required pyTigerGraph modules
# This should not be necessary once the required functionality is available in the build / via pip
# Remove this line if that's done
wget -O ~/workshop/scripts/solutions/fraud/pyTigerGraph.py https://raw.githubusercontent.com/szb-tg/pyTigerGraph/master/pyTigerGraph/pyTigerGraph.py
wget -O ~/workshop/scripts/solutions/fraud/pyTGCyto.py https://raw.githubusercontent.com/szb-tg/pyTigerGraph/master/pyTigerGraph/pyTGCyto.py
for F in `ls ~/workshop/scripts/solutions/fraud/*.py` ; do
    docker cp $F conda:/home/tigergraph
done
# Deploying notebooks
for F in `ls ~/workshop/scripts/solutions/fraud/*.ipynb` ; do
    docker cp $F conda:/home/tigergraph
done

echo "Importing MariaDB transaction data ..."
gunzip < $SOL_DIR/tg_mariadb_transactions.sql.gz | docker exec -i mariadb mysql -utigergraph -ptigergraph --default_character_set utf8mb4


# cleanups !!!
# (delete scripts and data not used!)


echo "Done deployment Fraud!"
echo "To stop this workshop:        docker-compose stop"
echo "To terminate this workshop:   docker-compose down"
