#!/bin/bash
echo "----> Starting deployment of Synthea-Medgraph solution ..."


echo "    ---- Waiting for TigerGraph to start roaring ..."
while ! docker exec $DOCKER curl --fail http://localhost:9000/echo &> /dev/null ; do
    sleep 1
done

echo "    ---- Initializing TigerGraph database (DDL) ..."
sleep 5

echo "docker exec -it --user tigergraph $DOCKER sh -c /opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/SyntheaDDL.gsql"
docker exec -it --user tigergraph $DOCKER sh -c "/opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/SyntheaDDL.gsql"

echo " *******************************************"
echo " * You can now open your browser and enter *"
echo " * http://localhost:14240                  *"
echo " * Username: tigergraph                    *"
echo " * Password: tigergraph                    *"
echo " *******************************************"

echo ""
echo ""

echo "    ---- Configuring Loading Jobs and loading data ..."
docker exec -it --user tigergraph $DOCKER sh -c "/opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/SyntheaLoadingJob.gsql"

echo " *******************************************"
echo " * Data loading finished                   *"
echo " *******************************************"

echo "    ---- Initializing TigerGraph queries (GSQL) ..."
docker exec -it --user tigergraph $DOCKER sh -c "/opt/tigergraph/app/cmd/gsql /home/tigergraph/scripts/SyntheaGSQLQueries.gsql"

# cleanups !!!
# (delete scripts and data not used!)
echo "--> Done deployment Synthea-Medgraph!"
